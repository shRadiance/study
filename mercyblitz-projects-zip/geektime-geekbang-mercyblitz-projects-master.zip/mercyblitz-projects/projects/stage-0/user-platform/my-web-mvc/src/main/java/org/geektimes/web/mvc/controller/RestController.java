package org.geektimes.web.mvc.controller;

/**
 * REST 控制器（标记接口）
 *
 * @since 1.0
 */
public interface RestController extends Controller {
}
