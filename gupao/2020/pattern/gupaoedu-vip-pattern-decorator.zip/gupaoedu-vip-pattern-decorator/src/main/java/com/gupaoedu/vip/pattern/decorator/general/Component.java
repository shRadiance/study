package com.gupaoedu.vip.pattern.decorator.general;

public abstract class Component {
    /** 
     * 示例方法 
     */  
    public abstract void operation();  
}  