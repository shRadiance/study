package com.gupaoedu.vip.pattern.command.general;

//抽象命令接口
public interface ICommand {
    void execute();
}