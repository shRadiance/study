package com.gupaoedu.vip.pattern.decorator.general;

public class ConcreteComponent extends Component {
  
    public void operation() {  
        //相应的功能处理
        System.out.println("处理业务逻辑");
    }  
  
}  