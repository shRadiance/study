package com.gupaoedu.vip.pattern.command.player;

/**
 * Created by Tom.
 */
public interface IAction {
    void execute();
}
