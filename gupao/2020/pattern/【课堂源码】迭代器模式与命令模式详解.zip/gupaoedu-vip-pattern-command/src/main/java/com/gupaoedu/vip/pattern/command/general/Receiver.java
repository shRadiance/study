package com.gupaoedu.vip.pattern.command.general;

//接收者
public class Receiver {
    public void action() {
        System.out.println("执行具体操作");
    }
}