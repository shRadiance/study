package com.gupaoedu.vip.pattern.decorator.battercake.v2;

/**
 * Created by Tom.
 */
public abstract class Battercake {

    protected abstract String getMsg();

    protected abstract int getPrice();

}
