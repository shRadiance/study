package com.gupaoedu.vip.pattern.iterator.course;

/**
 * Created by Tom.
 */
public class Course {
    private String name;

    public Course(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
