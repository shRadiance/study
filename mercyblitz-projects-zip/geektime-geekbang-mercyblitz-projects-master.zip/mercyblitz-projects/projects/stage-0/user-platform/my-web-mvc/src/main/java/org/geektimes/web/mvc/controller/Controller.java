package org.geektimes.web.mvc.controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Controller 接口（标记接口）
 * @since 1.0
 */
public interface Controller {

}
