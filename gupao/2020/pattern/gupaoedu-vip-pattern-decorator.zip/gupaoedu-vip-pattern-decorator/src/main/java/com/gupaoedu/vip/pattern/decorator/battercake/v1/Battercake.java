package com.gupaoedu.vip.pattern.decorator.battercake.v1;

/**
 * Created by Tom.
 */
public class Battercake {

    protected String getMsg(){ return "煎饼";}

    public int getPrice(){ return 5;}

}
